from dask.array.lib import stride_tricks
