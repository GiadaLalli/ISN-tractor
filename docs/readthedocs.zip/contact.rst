How to cite
===========

If you find this library useful, please cite: (AHAHAHAH)

About us
========

This library has been developed WHEN, WHERE, FUNDED BY WHOM

Disclaimer
==========

I did my best effort to make this library available to anyone, but bugs might be present.
Should you experience problems in using or installing it, or just to share any comment, please contact giada [dot] lalli [at] kuleuven [dot] be and zuqi [dot] li [at] kuleuven [dot] be.


