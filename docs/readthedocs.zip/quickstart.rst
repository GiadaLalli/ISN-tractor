Quickstart
==========

The ``examples`` folder contains some scripts showing how the ``ISN-Tractor`` library can be used, on both synthetic and real data.

Example 1: dense gene-based ISNs computation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

INSERT HERE
