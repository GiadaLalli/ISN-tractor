How to process data to be used by ISN-Tractor
=============================================

