Installation guide
==================

How do I set it up?
^^^^^^^^^^^^^^^^^^^

You can install ISN-Tractor from the GitHub Repository (ref) or from our PyPi package (ref).

In either ways, we recommend to follow these steps:

- James help me
- with life please

Install from git repo
^^^^^^^^^^^^^^^^^^^^^

Insert how

Install from pip
^^^^^^^^^^^^^^^^

Insert how
